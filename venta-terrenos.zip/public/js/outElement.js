
$(document).ready(function(){

   
    $("#mensaje").fadeOut(7000);
    $("#error").fadeOut(7000);
 
});
