<?php return array (
  'sidebar-nav-bar' => 'App\\Http\\Livewire\\SidebarNavBar',
);