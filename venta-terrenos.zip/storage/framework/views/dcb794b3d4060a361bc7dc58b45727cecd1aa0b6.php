<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Nota de credito</title>    
</head>
<body>

<style>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
td,th,tr,table {
    border-top: 1px solid black;
    border-collapse: collapse;
}

td.cantidad,th.cantidad {
    word-break: break-all;
}
td.precio,th.precio {
    word-break: break-all;
}
.centrado {
    text-align: center;
    align-content: center;
    width: 100%;
}
img {
    max-width: inherit;
    width: inherit;
}
@media  print{
  .oculto-impresion, .oculto-impresion *{
    display: none !important;
  }
}

</style>
<div>
    <img class="center" src="<?php echo e(asset('/logo_inusual.png')); ?>" alt="Logotipo">
    <p class="centrado">
        
        Atendido por <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?> <br>
        Fecha: <?php echo e($sale->created_at->format('d-m-y h:m:s')); ?> <br>
        Folio: <?php echo e($sale->id); ?>

    </p>
    <section style="display: flex; justify-content: space-between; align-items: center;">
        <div id="pro-th">CANTIDAD</div>
        <div id="pre-th">PRODUCTO  <br></div>
        <div id="cod-th">PRECIO</div>
        <div id="subtotal">DESCUENTO</div>
        <div id="subtotal">TOTAL</div>
    </section>
    <hr>
    <?php $__currentLoopData = $sale->productsInSale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display: flex; align-items: center; justify-content: space-between;">
            <div id="pro-td">
                <?php echo e($product->quantity); ?>

            </div>
            <div id="pre-td" style="text-align: center;"><?php echo e($product->product->name); ?> </div>
            <div id="can-td" style="text-align: center; margin-right:1em !important;">$<?php echo e(number_format($product->sale_price,2,',','.')); ?> </div>
            <div id="can-td" style="text-align: center; margin-right:1em !important;"><?php if($product->discount != 0): ?>$<?php echo e(number_format($product->discount,2,',','.')); ?><?php else: ?>-<?php endif; ?></div>
            <div id="subtotal" style="text-align: center;">$<?php echo e(number_format($product->subtotal,2,',','.')); ?> </div>
        </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div id="total">
      
        <?php if($sale->discount != null): ?>Descuento:  %<?php echo e(number_format($sale->discount,2,'.',',')); ?><?php endif; ?>
        <br>
        Subtotal:  $<?php echo e(number_format($sale->cart_subtotal,2,'.',',')); ?>

        <br>
        Total: $<?php echo e(number_format($sale->cart_total,2,'.',',')); ?>

    </div>
    <p class="centrado">RFC:<?php echo e(Auth::user()->rfc); ?> </p>
    <p class="centrado">Email: <?php echo e(Auth::user()->email); ?></p>
    <p class="centrado">¡GRACIAS POR SU COMPRA!</p>
    <br/>
    <br/>
    <br/>
    <p class="centrado">_____________________________</p>
    <p class="centrado"><?php echo e($client->name." ".$client->last_name); ?></p>

</div>
</body>
<script>
    window.print();
    window.addEventListener("afterprint", function(event) {
        window.close()
    });
</script>
</html>
<?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\venta-terrenos\resources\views/sale/nota.blade.php ENDPATH**/ ?>