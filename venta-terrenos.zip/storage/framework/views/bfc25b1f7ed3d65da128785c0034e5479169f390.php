<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e($project[0]->name); ?>


            <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"
                class="font-semibold btn btn-outline-warning  float-right">
                <i class="bi bi-pencil">Cambiar estatus</i>
            </button>
        </h2>
     <?php $__env->endSlot(); ?>
    
    <br>
    <div class="float-right">
        <h3>Estatus: </h3>
        <button class="btn btn-outline-secondary "   data-bs-toggle="modal" data-bs-target="#progressModal">
            <?php echo e($project[0]->progress); ?></button>
    </div>
<br>
    
    <div class="py-12">
        
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">       
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

                <div class="container">
                    <table class="table table-hover">
                        <thead>
                            <tr>

                                <th>Inversionista</th>
                                <th>Monto invertido</th>
                                <th>Fecha</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $project[0]->investor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>

                                    <td><?php echo e($proyecto->name); ?></td>
                                    <td>$<?php echo e($proyecto->pivot->amount); ?></td>
                                    <td><?php echo e($proyecto->pivot->created_at); ?></td>

                                </tr>
                                <!-- Modal -->

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="container">
                    <h1>Ventas</h1>
                    <table class="table table-hover">
                        <thead>
                            <tr>

                                <th>Codigo de barras</th>
                                <th>Colonia</th>
                                <th>Precio venta</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $project[0]->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>

                                    <td><?php echo e($product->bar_code); ?></td>
                                    <td><?php echo e($product->colonia); ?></td>
                                    <td>$<?php echo e($product->productInSales[0]->total); ?></td>
                                    <td><?php echo e($product->productInSales[0]->created_at); ?></td>

                                </tr>
                                <!-- Modal -->

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('projects.progress', $project[0]->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Agregar progreso del proyecto</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="">Comentario</label>
                                    <input type="text" class="form-control" name="progresss">
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="">Estatus</label>
                                    <select class="form-control" name="status_progress" id="">
                                        <option value="0" selected disabled>Selecciona un encargado para esta proyecto
                                        </option>
                                        <option value="En-movimientos">En movimientos</option>
                                        <option value="Terminado">Terminado</option>
                                    </select>
                                </div>
                            </div>

                        </div>


                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-success">Guardar</button>
                        </div>
                </form>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    <div class="modal fade" id="progressModal" tabindex="-1" aria-labelledby="progressModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('projects.progress', $project[0]->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="progressModalLabel">Lista de comentarios</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-hover">
                            <thead>
                                <tr>

                                    <th>Comentarios</th>
                                    <th>Fecha</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $project[0]->projectProgress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemProgress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    <tr>

                                        <td><?php echo e($itemProgress->progresss); ?></td>
                                        <td><?php echo e($itemProgress->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                </form>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\venta-terrenos\resources\views/projects/ditails.blade.php ENDPATH**/ ?>